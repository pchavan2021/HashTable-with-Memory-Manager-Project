import java.util.Arrays;
/**
 * @author pallucha21 and evanhowe03
 * @version 1.0
 */
public class Record implements Comparable<Record> {
    
    private byte[] key = new byte[2];
    private byte[] value = new byte[2];
    
    // A flag indicating if the data in the buffer 
    // has been modified (written to) and not yet saved back to the disk.
    private boolean isDirty;
  //offset in the file where this block begins
    private int position;

    /**
     * constructor
     */
    public Record() {
        isDirty = false;
    }
    
  
    public void markDirty() {
        this.isDirty = true;
    }

    /**
     * get the key
     * @return the byte array
     */
    public byte[] getKey() {
        return this.key;
    }
    
    /**
     * set the key
     * @param a byte array
     */
    public void setKey(byte[] a) {
        this.key = a;
    }
    
    /**
     * get the value
     * @return the byte array
     */
    public byte[] getValue() {
        return this.value;
    }
    
    /**
     * set the value
     * @param a the byte array
     */
    public void setValue(byte[] a) {
        this.value = a;
    }

    @Override
    public int compareTo(Record other) {
        return Short.compare(toShort(this.key), toShort(other.key));
    }

    /**
     * return the short
     * @param bytes list
     * @return a short
     */
    private static short toShort(byte[] bytes) {
        return (short)((bytes[0] << 8) | (bytes[1] & 0xFF));
    }

    /**
     * return the strin gof the key
     * @return a string
     */
    public String toString() {
        return "key: " + toShort(key);
    }

}