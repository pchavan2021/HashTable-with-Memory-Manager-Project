/**
 * this is the sorter class
 * 
 * The class containing the main method.
 *
 * @author pallucha21 and evanhowe03
 * @version 1.0
 */
public class Sorter {

    /**
     * this is the constructor
     * @param records list
     */
    public Sorter(Record[] records) {

        quickSort(records, 0, records.length - 1);

    }

    /**
     * this is the quicksort
     * @param A array
     * @param i starting pos
     * @param j ending pos
     */
    private void quickSort(Record[] a, int i, int j) {

        int pivot = findPivot(a, i, j);

        swap(a, pivot, j);

        int k = partition(a, i, j - 1, j);

        swap(a, k, j);

        if ((k - i) > 1) {

            quickSort(a, i, k - 1);

        }

        if ((j - k) > 1) {
            quickSort(a, k + 1, j);
        }

    }


    private int findPivot(Record[] toSort, int i, int j) {

        return (i + j) / 2;
    }


    private int partition(
        Record[] toSort,
        int left,
        int right,
        int pivotIndex) {

        Record pivot = toSort[pivotIndex];

        while (left <= right) {
            while (left <= right && toSort[left].compareTo(
                pivot) < 0) {
                left++;
            }
            while (left <= right && toSort[right].compareTo(
                pivot) >= 0) {
                right--;
            }
            if (left < right) {
                swap(toSort, left, right);
                left++;
                right--;
            }
        }

        return left;
    }


    public void swap(Record[] a, int index1, int index2) {
        if (a == null) {
            throw new IllegalArgumentException("Invalid");
        }

        // System.out.println("ran" + index2);
        Record temp = a[index1];
        a[index1] = a[index2];
        a[index2] = temp;

    }

}