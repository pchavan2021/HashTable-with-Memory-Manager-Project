
/**
 * {Project Description Here}
 */

import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Random;

/**
 * The class containing the main method.
 *
 * @author {Your Name Here}
 * @version {Put Something Here}
 */

// On my honor:
//
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project with
// anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

public class Quicksort {
    private static BufferPool buffPool;

    /**
     * This method is used to generate a file of a certain size, containing a
     * specified number of records.
     *
     * @param filename
     *            the name of the file to create/write to
     * @param blockSize
     *            the size of the file to generate
     * @param format
     *            the format of file to create
     * @throws IOException
     *             throw if the file is not open and proper
     */
    public static void generateFile(
        String filename,
        String blockSize,
        char format)
        throws IOException {
        FileGenerator generator = new FileGenerator();
        String[] inputs = new String[3];
        inputs[0] = "-" + format;
        inputs[1] = filename;
        inputs[2] = blockSize;
        generator.generateFile(inputs);
    }


    /**
     * @param args
     *            Command line parameters.
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {

        String fileName = "input.txt";
        int totalBufferPoolLength = Integer.parseInt(args[1]);
        String outputStats = args[2];

        try {
            // Quicksort.generateFile(fileName, "4096", 'a');
            long start = System.currentTimeMillis();
            RandomAccessFile raf = new RandomAccessFile(fileName,
                "rw");
            int times = 0;
            while (raf.getFilePointer() < raf.length()) {
                
                int fileLength = (int)raf.length();
                byte[] byteArray = new byte[fileLength];
                //byte[] byteArray = new byte[4096];

                int bytesRead = raf.read(byteArray);

                if (bytesRead < fileLength) {
                    byteArray = Arrays.copyOf(byteArray, bytesRead);
                }

                byteArray = sortByteArray(byteArray);

                raf.seek(raf.getFilePointer() - bytesRead);

                raf.write(byteArray);
                times++;
                System.out.println("tyime" + times);
            }
            long endTime = System.currentTimeMillis();
            printStats(outputStats, fileName, endTime - start);
            System.out.println("Sort Execution Time (ms): " + (endTime
                - start));
            raf.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void printStats(
        String fileName,
        String dataFileName,
        long runtime)
        throws IOException {
        try (FileWriter writer = new FileWriter(fileName, true)) {

            writer.write("Sort Execution Time (ms): " + runtime
                + "\n");
            writer.write("------------------------------------\n");
        }
    }

    /**
     * sorty byte array
     * @param data thus ui sdata
     * @return array
     */
    public static byte[] sortByteArray(byte[] data) {

        int numRecords = data.length / 4;
        Record[] records = new Record[numRecords];

        for (int i = 0; i < numRecords; i++) {
            Record newRecord = new Record();
            records[i] = newRecord;

            byte[] key = records[i].getKey();
            byte[] value = records[i].getValue();
            System.arraycopy(data, i * 4, records[i].getKey(), 0, 2);
            System.arraycopy(data, i * 4 + 2, records[i].getValue(), 0, 2);

        }

        //Sorter machine = new Sorter(records);
        Arrays.sort(records);

        byte[] sortedData = new byte[data.length];
        for (int i = 0; i < numRecords; i++) {
            System.arraycopy(records[i].getKey(), 0, sortedData, i * 4, 2);
            System.arraycopy(records[i].getValue(), 0, sortedData, i * 4
                + 2, 2);
        }

        System.out.println(Arrays.toString(records));

        return sortedData;
    }

    /**
     * 
     * static void quickSort(Record[] A, int i, int j) {
     * int pivotIndex = findPivot(A, i, j);
     * swap(A, pivotIndex, j);
     * 
     * int k = partition(A, i, j - 1, A[j]);
     * swap(A, k, j);
     * if ((k - i) > 1) {
     * quickSort(A, i, k - 1);
     * } // Sort left partition
     * if ((j - k) > 1) {
     * quickSort(A, k + 1, j);
     * } // Sort right partition
     * }
     * 
     * 
     * static int partition(Record[] A, int left, int right, Record pivot) {
     * while (left <= right) { // Move bounds inward until they meet
     * while (left < A.length && A[left].compareTo(pivot) < 0) {
     * left++;
     * }
     * while ((right >= left) && A[right].compareTo(pivot) >= 0) {
     * right--;
     * }
     * if (right > left) {
     * swap(A, left, right);
     * } // Swap out-of-place values
     * }
     * return left;
     * }
     * 
     * 
     * static int findPivot(Record[] A, int i, int j) {
     * return (i + j) / 2;
     * }
     * 
     * static void swap(Record[]A, int index1, int index2) {
     * if (A == null || index1 < 0 || index2 < 0 || index1 >= A.length || index2
     * >= A.length) {
     * throw new IllegalArgumentException("Invalid");
     * }
     * 
     * Record temp = A[index1];
     * A[index1] = A[index2];
     * A[index2] = temp;
     * 
     * }
     **/
}