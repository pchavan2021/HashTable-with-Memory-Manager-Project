import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author pallucha21 and evanhowe03
 * @version 1.0
 */
public class BufferPool {

    private RandomAccessFile disk;
    private Buffer[][] pool;
    private int totalBlocksInFile;
    private final static int BLOCK_SIZE = 4096;
    private final static int RECORD_SIZE = 4;

    /**
     * this is the constructor
     * 
     * @param fileName
     *            this is a file
     * @param numBuffers
     *            this a numbuffers
     */
    public BufferPool(File file, int numBuffer) throws IOException {

        disk = new RandomAccessFile(file, "rw");

        totalBlocksInFile = (int)disk.length() / BLOCK_SIZE;

        pool = new Buffer[numBuffer][BLOCK_SIZE];
    }


    /**
     * insert a buffer into the buffer pool
     * 
     * @param buffer
     *            this is the buffer
     * @throws IOException
     */
    public void insert(Record rec) throws IOException {

        // insert the record into the pool
        // if the pool is at it's capacity
        // use the LRU to writeBack to the file

       

    }


    /**
     * adds the record to the next
     * open spot
     * 
     * @param rec
     * @return whether the pool
     *         is full or not
     */
    public boolean add(Record rec) {
        int nextIndex = 0;
        if (nextIndex < pool.length) {
            pool[nextIndex].add(rec);
            nextIndex++;
        } else {
            System.out.println("Array is full. Can't add more items.");
        }
        
    }
    
    
    public Buffer getBuffer(Record rec) {
        //get a buffer for a specific block from the pool.
        
        //if the block is found, return the most recently used buffer
        //which is likely the rear
    }
    
    public short getKey(int row, int col) {
        //return the key for the specific record at the
        //given directions
        
    }
    
    public void flush() 
        throws IOException {
        //remove all the buffers from the pool
        //write them back into the file
        
    }
 
    /**
     * 
     * @return the buffers
     */
    public Buffer[][] getArray() {
        return buffers;
    }


    @Override
    public Record[] readBlock() {

        return null;
    }



}
